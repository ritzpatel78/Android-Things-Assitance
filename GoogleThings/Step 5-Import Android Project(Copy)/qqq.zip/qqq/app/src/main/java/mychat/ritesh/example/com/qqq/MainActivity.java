package mychat.ritesh.example.com.qqq;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.google.android.things.pio.Gpio;
import com.google.android.things.pio.PeripheralManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;

public class MainActivity extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private DatabaseReference fanon;
    private  DatabaseReference fanoff;
    private  DatabaseReference lightoff;
    private  DatabaseReference lighton;
    int c=0,d=0,r1,r2=1;
    private Gpio mLedGpio;

    @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            Log.i(TAG, "Starting ButtonActivity");

            PeripheralManager pioService;
            pioService= PeripheralManager.getInstance();
            try {
                Log.i(TAG, "Configuring GPIO pins");
                mLedGpio = pioService.openGpio(BoardDefaults.getGPIOForLED());
                mLedGpio.setDirection(Gpio.DIRECTION_OUT_INITIALLY_LOW);

            } catch (IOException e) {

                Log.e(TAG, "Error configuring GPIO pins", e);
            }
        }

        @Override

        protected void onStart() {
            super.onStart();

            setLedValue(false);
            sleep(2000);

           /* Runnable ledBlinker = new Runnable() {
                @Override
                public void run() {
                    while(true) {
                        // Turn on the LED
                        setLedValue(true);
                        sleep(400);

                        // Turn off the LED
                        setLedValue(false);
                        sleep(200);
                    }
                }
            };
            new Thread(ledBlinker).start();**/
          /*  fanon= FirebaseDatabase.getInstance().getReference().child("fan_on");
            String Fon=fanon.toString();
            fanoff= FirebaseDatabase.getInstance().getReference().child("fan_off");
            String Foff=fanoff.toString();**/
            lighton= FirebaseDatabase.getInstance().getReference().child("onl");
            String Lon=lighton.toString();
            lightoff= FirebaseDatabase.getInstance().getReference().child("offl");
            String Loff=lightoff.toString();

            lighton.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    if(dataSnapshot.exists())
                    {
                        final String on=dataSnapshot.getValue().toString();
                        lightoff.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot)
                            {
                                String off=dataSnapshot.getValue().toString();

                                if(on.equals("1"))
                                {
                                    setLedValue(true);
                                    sleep(4000);

                                    c=1;
                                }
                                else if(on.equals("")&&off.equals("0"))
                                {
                                    setLedValue(false);
                                    sleep(400);

                                    c=0;
                                }
                                else if(on.equals("")&&off.equals("")&& c==1)
                                {
                                    setLedValue(true);
                                    sleep(400);

                                }
                                else if(off.equals("0"))
                                {
                                    setLedValue(false);
                                    sleep(400);

                                    d=1;
                                }
                                else if(on.equals("1")&&off.equals(""))
                                {
                                    setLedValue(true);
                                    sleep(400);

                                    d=0;
                                }
                                else if(on.equals("")&&off.equals("")&& d==1)
                                {
                                    setLedValue(false);
                                    sleep(400);

                                }
                                else {setLedValue(false);
                                    sleep(400);
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });

                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError)
                {
                    Log.w(TAG, "Failed to read value.");
                }
            });

            for(r1=0;r1<r2;r1++)
            {
                r2=r2+1;
                sleep(5000);
                Log.i(TAG, "Refreshing ");
                refresh();
               // Log.i(TAG, "Iteration NO");
            }

        }

        private void sleep(int milliseconds){
            try {
                Thread.sleep(milliseconds);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        /**
         * Update the value of the LED output.
         */
        private void setLedValue(boolean value) {
            try {
                mLedGpio.setValue(value);
            } catch (IOException e) {
                Log.e(TAG, "Error updating GPIO value", e);
            }
        }

        @Override
        protected void onDestroy(){
            super.onDestroy();

            Runnable ledBlinker = new Runnable() {
                @Override
                public void run() {
                    while(true) {
                        // Turn on the LED
                       /* setLedValue(true);
                        sleep(400);***/

                        // Turn off the LED
                        setLedValue(false);
                        sleep(1100);
                    }
                }
            };
            new Thread(ledBlinker).start();
        }

        protected void refresh()
        {
                setLedValue(false);
                sleep(2000);
                lighton= FirebaseDatabase.getInstance().getReference().child("onl");
                String Lon=lighton.toString();
                lightoff= FirebaseDatabase.getInstance().getReference().child("offl");
                String Loff=lightoff.toString();

        lighton.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot)
            {
                if(dataSnapshot.exists())
                {
                    final String on=dataSnapshot.getValue().toString();
                    lightoff.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot)
                        {
                            String off=dataSnapshot.getValue().toString();

                            if(on.equals("1"))
                            {
                                setLedValue(true);
                                sleep(4000);

                                c=1;
                            }
                            else if(on.equals("")&&off.equals("0"))
                            {
                                setLedValue(false);
                                sleep(400);

                                c=0;
                            }
                            else if(on.equals("")&&off.equals("")&& c==1)
                            {
                                setLedValue(true);
                                sleep(400);

                            }
                            else if(off.equals("0"))
                            {
                                setLedValue(false);
                                sleep(400);

                                d=1;
                            }
                            else if(on.equals("1")&&off.equals(""))
                            {
                                setLedValue(true);
                                sleep(400);

                                d=0;
                            }
                            else if(on.equals("")&&off.equals("")&& d==1)
                            {
                                setLedValue(false);
                                sleep(400);

                            }
                            else {setLedValue(false);
                                sleep(400);
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError)
            {
                Log.w(TAG, "Failed to read value.");
            }
        });
    }


}